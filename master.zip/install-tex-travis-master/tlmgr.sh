#!/bin/bash

tlmgr -repository http://ctan.sharelatex.com/tex-archive/systems/texlive/tlnet $@
